/*
 * YahtzeeApplet.java
 *
 * Created on May 29, 2005, 10:51 PM
 *
 */

package unrealyahtzee;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.*;

public class YahtzeeApplet extends JApplet implements ActionListener, YahtzeeUI
{
  
  public static final String VERSION = new String("1.0");

  public static final int maxPlayersPerGame = 4;
  public static final int numberOfDie = 5;
  public static final int numberOfCategories = 13;
  public static final int numberOfDieFaces = 6;

  private static final int noWinner = -1;
  private static final String imagePath = "images";
  private static final String unknownPoints = "---";

  public static final String categoryNames[] = {
    "Aces",            // 0
    "Twos",            // 1
    "Threes",          // 2
    "Fours",           // 3
    "Fives",           // 4
    "Sixes",           // 5
    "3 of a Kind",     // 6
    "4 of a Kind",     // 7
    "Full House",      // 8
    "Small Straight",  // 9
    "Large Straight",  // 10
    "Yahtzee",         // 11
    "Chance"           // 12
  };     
    
  private ImageIcon[] dieImage = new ImageIcon[numberOfDieFaces];
  private ImageIcon[] dieSelectedImage = new ImageIcon[numberOfDieFaces];
  private ImageIcon[] categoryImage = new ImageIcon[numberOfCategories];

  private ImageIcon yahtzeeIcon = null;
  private ImageIcon[] miniDieImage = new ImageIcon[numberOfDieFaces];

  private ImageIcon threeIcon = null;
  private ImageIcon twoIcon = null; 
  private ImageIcon oneIcon = null; 
  private ImageIcon zeroIcon = null;  
  
  private ImageIcon blankIcon = null; 
  
  private JButton rollButton = new JButton("ROLL");
  private JButton suggestButton = new JButton("SUGGEST");
  private JButton connectButton = new JButton("Connect");  
  
  private JLabel[] identityLabel = new JLabel[maxPlayersPerGame];
  private String[] playerName = new String[maxPlayersPerGame];
  private SelectableLabel[] dieLabel = new SelectableLabel[numberOfDie];
  private SelectableLabel scoreLabel[][] = new SelectableLabel[maxPlayersPerGame][numberOfCategories];
  private SelectableLabel assignedDieLabel[][][] = new SelectableLabel[maxPlayersPerGame][numberOfDie][numberOfCategories];
  private JLabel rollsRemainingLabel = new JLabel();  
  
  private SelectableLabel[] categoryLabel = new SelectableLabel[numberOfCategories];
  private SelectableLabel[] pointsLabel = new SelectableLabel[numberOfCategories];
  private JLabel[] upperTotalLabel = new JLabel[maxPlayersPerGame];
  private JLabel[] bonusLabel = new JLabel[maxPlayersPerGame];  
  private JLabel[] lowerTotalLabel = new JLabel[maxPlayersPerGame];
  private SelectableLabel[] grandTotalLabel = new SelectableLabel[maxPlayersPerGame];
    
  private YahtzeeClient yahtzeeClient = null;
  private boolean categoryAssigned = false;  
    
  private JTextField identityText = new JTextField(10);
  private JTextField addressText = new JTextField(15);
  private JTextField portText = new JTextField("2626", 4);
  private JLabel connectStatusLabel = new JLabel();
  private JLabel gameStatusLabel = new JLabel();
  //private JButton resetButton = new JButton("Reset");
  private JButton hostButton = new JButton("Host");
  private JButton startButton = new JButton("Start");    
  private JLabel timerLabel = new JLabel("00:00");
    
  private int assignedPlayerIndex = 0;
  private int winnerIndex = noWinner;  // index of the player who has won the game (-1 if none)

  private GameCoordinator gameCoordinator;
  
  private YahtzeeServer yahtzeeServer = null;  
  
  private Action updateTimerAction = new AbstractAction() 
    {
      private long initialTime = System.currentTimeMillis();
      public void actionPerformed(ActionEvent e)
      {
        long delta = (System.currentTimeMillis() - initialTime) / 1000;  // seconds      
        long minutes = delta / 60;
        long seconds = (delta % 60);
        String time = "";
        if (minutes < 10)
        {
          time += "0";
        }
        time += minutes + ":";
        if (seconds < 10)
        {
          time += "0";
        }
        time += seconds;
        timerLabel.setText(time);
      }
    };

  private void actionAssignedDieClicked(java.awt.event.MouseEvent evt)
  {
    SelectableLabel label = (SelectableLabel)evt.getComponent();  
    for (int i = 0; i < maxPlayersPerGame; ++i)
    {
      for (int j = 0; j < numberOfDie; ++j)
      {
        for (int k = 0; k < numberOfCategories; ++k)
        {
          if (assignedDieLabel[i][j][k] == label)
          {
              if (assignedPlayerIndex == i)
              {
                java.awt.event.MouseEvent c_evt = new java.awt.event.MouseEvent(categoryLabel[k], 0, 0, 0, 0, 0, 0, false);
                actionCategoryMouseClicked(c_evt);
              }
              break;
          }
        }
      }
    }
  }
  
  private void actionCategoryMouseClicked(java.awt.event.MouseEvent evt)
  {
    if (winnerIndex != noWinner)
    {
      setGameStatus("The game has already been won.  Restart the applet to play again!");
      return;
    }
    
    if ( (!rollButton.isEnabled()) & (gameCoordinator.rollsRemaining() > 0) ) 
    {
      // The die are rolling or it's not the players turn yet
      setGameStatus("The dice haven't finished rolling yet!");
      return;
    }
    
    if (gameCoordinator.rollsRemaining() >= 3)
    {
      setGameStatus("Roll the dice first!");  
    }
    else if (categoryAssigned)
    {
      String s = "The roll has already been assigned to a category.  Roll again!";
      if ((yahtzeeClient != null) || (yahtzeeServer != null))
      {
        s += " (is it your turn?)";
      }
      setGameStatus(s);
    }
    else
    {
      SelectableLabel label = (SelectableLabel)evt.getComponent();
      int categoryIndex = label.getNumber();
      if (gameCoordinator.assignRollToCategory(categoryIndex))
      {      
        Vector dieValues = gameCoordinator.dieValues();
        for (int i = 0; i < numberOfDie; ++i)
        {
          int dieValue = (Integer)dieValues.elementAt(i);
          assignedDieLabel[assignedPlayerIndex][i][categoryIndex].setIcon( miniDieImage[ dieValue-1 ] );
          assignedDieLabel[assignedPlayerIndex][i][categoryIndex].setNumber(dieValue);
        }
        int score = gameCoordinator.score(categoryIndex,  dieValues);
        scoreLabel[assignedPlayerIndex][categoryIndex].setText( Integer.toString(score) );
        scoreLabel[assignedPlayerIndex][categoryIndex].setNumber( score );
        categoryAssigned = true;
        setGameStatus("Roll has been assigned to category " + (categoryIndex+1) + " (" + categoryNames[categoryIndex] + ")");
        doNextTurn();
      }
      else
      {
        // category already assigned, make some noise
        setGameStatus("That category has already been assigned by a previous roll.");
      }
    }
  }
  
  private void actionDieMouseClicked(java.awt.event.MouseEvent evt) 
  {
    if (winnerIndex != noWinner)
    {
      setGameStatus("The game has already been won.  Restart the applet to play again!");
      return;
    }
    
    int rollsLeft = gameCoordinator.rollsRemaining();
    if ( (!rollButton.isEnabled()) & (rollsLeft > 0))
    {
      // The die are rolling
      setGameStatus("Wait for the die to stop rolling!");
      return;      
    }
    if (rollsLeft >= 3)
    {
      // The game hasn't started yet
      if (gameCoordinator.turnCount() > 0)
      {
        setGameStatus("Roll the dice first!");
      }
      else
      {
        setGameStatus("The game has not started yet! Roll first.");
      }
    }
    else if (rollsLeft <= 0)
    {
      // No rolls left, no need to select
      if (categoryAssigned)
      {
        setGameStatus("The roll has already been assigned to a category.  Roll again!");
      }
      else
      {
        setGameStatus("No rerolls remaining.  You must assign the roll to a category."); 
      }
    }
    else
    {
      Vector dieValues = gameCoordinator.dieValues();       
      
      SelectableLabel label = (SelectableLabel)evt.getComponent();
      int dieIndex = label.getNumber();
      label.invertSelection();
      
      int faceValueIndex = (Integer)dieValues.elementAt(dieIndex) - 1;
      
      if (label.isSelected())  //dieSelected[dieIndex])
      {
        label.setIcon( dieSelectedImage[faceValueIndex] );
      }
      else
      {
        label.setIcon( dieImage[faceValueIndex] );
      }
    }
  }
  
  private void actionEnteredPointsMotion(java.awt.event.MouseEvent evt)
  {
    SelectableLabel label = (SelectableLabel)evt.getSource();
    int category = label.getNumber();
    int score = gameCoordinator.score(category, gameCoordinator.dieValues());
//    System.out.println("Points label for category " + label.getNumber() + ", score = " + score);
    String scoreStr = Integer.toString(score);
    while (scoreStr.length() < unknownPoints.length())
    {
      scoreStr = "0" + scoreStr;
    }
    pointsLabel[category].setText( scoreStr );
  }
  
  private void actionExitedPointsMotion(java.awt.event.MouseEvent evt)
  {
    SelectableLabel label = (SelectableLabel)evt.getSource();
    int category = label.getNumber();
    pointsLabel[category].setText( unknownPoints );
  }
  
  public void actionPerformed( ActionEvent e )
  {
    JButton source = (JButton)e.getSource();
    if (source == rollButton)
    {
      hostButton.setEnabled(false);  // disable Net player (for single player), or it is disabled already after Net player activated
      connectButton.setEnabled(false);
      
      rollButton.setEnabled(false);
      if (categoryAssigned)
      {
        categoryAssigned = false;
        gameCoordinator.nextTurn();
        setGameStatus("Rolling the dice for turn " + Integer.toString(gameCoordinator.turnCount()+1) + ".");
        scrambleAllDie();
      }
      else if (gameCoordinator.rollsRemaining() <= 0)
      {
        if (categoryAssigned)
        {
          setGameStatus("Roll has been assigned to a category.  Roll again !"); 
        }
        else
        {
          setGameStatus("No rerolls remaining. You must assign the roll to a category.");
        }
      }
      else
      {
        int i;
        for (i = 0; i < dieLabel.length; ++i)
        {
          if (dieLabel[i].isSelected())
          {
            break;
          }
        }
        if (i == dieLabel.length)
        {   
          // No die were selected, automatically reroll all of them
          setGameStatus("Rolling all the dice.");
          gameCoordinator.rerollAll();
          scrambleAllDie();
        }
        else
        {
          // partial reroll
          setGameStatus("Rolling the selected die.");
          gameCoordinator.reroll(dieLabel);
          scrambleSelectedDie();
        }        
      }
    }
    else if (source == suggestButton)
    {
      // TBD
    }
    //else if (source == resetButton)
    //{
    //  restartGame();
    //}
    else if (source == hostButton)
    {
      // SETUP SERVER
      yahtzeeServer = new YahtzeeServer(this, Integer.parseInt( portText.getText() ),  addressText.getText());
      if (yahtzeeServer != null)
      {
        yahtzeeServer.start();
        try 
        {
          Thread.sleep(20);  // give time for the server to actually start listening for clients
        } catch (Exception ex)
        {
        }
        if ((yahtzeeServer != null) && (yahtzeeServer.isAlive()))
        {
          startButton.setEnabled(false);
          hostButton.setEnabled(false);
          rollButton.setEnabled(false);
          connectButton.setEnabled(false);
          suggestButton.setEnabled(false);
        }
        else
        {
          yahtzeeServer = null;
        }   
        setPlayerName(1, getIdentity());
      }
    }
    else if (source == startButton)
    {
      startButton.setEnabled(false);
      yahtzeeServer.setAcceptingConnections(false);
      yahtzeeServer.setGameInProgress(true);
      rollButton.setEnabled(true);
      yahtzeeServer.broadcastStartOfGame(playerName);
      setConnectStatus("Start. No more players will be accepted.");
    }
    else if (source == connectButton)
    {
      yahtzeeClient = new YahtzeeClient(this);
      if (yahtzeeClient.connect(addressText.getText(), Integer.parseInt(portText.getText())))
      {
        yahtzeeClient.start();
        rollButton.setEnabled(false);
        hostButton.setEnabled(false);
        connectButton.setEnabled(false);
      }
      else
      {
        yahtzeeClient = null;
        //setConnectStatus("Unable to connect to server");
      }
    }
  }
  
  private void doNextTurn()
  {
    updateUpperLowerTotals();
    
    rollButton.setEnabled(false);
    gameCoordinator.endTurn();
    
    if (yahtzeeServer != null)
    {
      setConnectStatus("Server category assigned.  Next client turn.");
      yahtzeeServer.broadcastCategoryAssignments(assignedDieLabel, scoreLabel);      
      yahtzeeServer.nextPlayer();
    }
    else if (yahtzeeClient != null)
    {
      //setConnectStatus("Client category assigned.  Next players turn.");      
      yahtzeeClient.broadcastCategoryAssignments(assignedDieLabel);
      yahtzeeClient.nextPlayer();
    }
    else
    {
      // Single player game
      yourTurn();
    }
    
    this.updateRollsRemaining();
  }
    
  public void gameCanStart()
  {
    startButton.setEnabled(true);
  }
  
  public void gameOver(int winningPlayerNumber)
  {
    winnerIndex = winningPlayerNumber - 1;
    if ((yahtzeeServer != null) || (yahtzeeClient != null))
    {
      if (winnerIndex == assignedPlayerIndex)
      {
        setGameStatus("You scored the highest!");
      }
      else
      {
        setGameStatus(identityLabel[winnerIndex].getText() + " has won the game!");
      }
    }
    else
    {
      // Single Player Mode
      setGameStatus("Game Over");
    }
  }
  
  public String getIdentity() 
  {
    String s = identityText.getText();
    if (s.equals(""))
    {
      s = addressText.getText();
      if (s.equals(""))
      {
        s = "UNKOWN";
      }
    }
    return s;
  }  
  
  public void init()
  { 
    /* Approximate layout of GUI:
     
       Identity  ___________    [Connect] ______________  Port _____   connectStatusLabel  [host] [start]
       [                   die1     die2    die3    die4    die5          ]  rollRemaining
                                                   [roll] [suggest]
       category_header  points  identity1        identity2        identity3        identity4
       Category 1         ---   _ _ _ _ _  sc_p1  _ _ _ _ _ sc_p2 _ _ _ _ _ sc_p3  _ _ _ _ _ sc_p4
       ...
       upper total                p1_ut             p2_ut           p3_ut             p4_ut
       bonus                      p1_bon            p2_bon          p3_bon            p4_bon
       ...
       Category N         ---   _ _ _ _ _   sc_p1 _ _ _ _ _ sc_p2  _ _ _ _ _ sc_p3 _ _ _ _ _ sc_p4
       lower total                p1_lt             p2_lt           p3_lt             p4_lt
       grand total                p1_gt             p2_gt           p3_gt             p4_gt
       timer  gameStatusLabel
     
     */
    setGameStatus("Welcome to UnrealYahtzee (version " + VERSION + ")");

    // Load static image icons...
    yahtzeeIcon = loadImage(imagePath + "/yahtzee.gif");  //this.getClass().getResource(imagePath + "/yahtzee.gif"));
    threeIcon = loadImage(imagePath + "/roll3.gif");
    twoIcon = loadImage(imagePath + "/roll2.gif");
    oneIcon = loadImage(imagePath + "/roll1.gif");
    zeroIcon = loadImage(imagePath + "/roll0.gif");
    
    blankIcon = loadImage(imagePath + "/blank.gif");
    
    try 
    {
      byte[] ia_b = InetAddress.getLocalHost().getAddress();
      // Convert the signed bytes into unsigned integers...
      int[] ia = new int[ia_b.length];
      for (int i = 0; i < ia.length; ++i)
      {
        ia[i] = ia_b[i] & 0xFF;
      }
      String iaStr = Integer.toString(ia[0]) + "." + Integer.toString(ia[1]) + "." + Integer.toString(ia[2]) + "." + Integer.toString(ia[3]);
      addressText.setText(iaStr);
    }
    catch (Exception e)
    {
      addressText.setText("localHost");
    } 
    
    for (int index = 0; index < numberOfCategories; ++index)
    {
      categoryImage[index] = loadImage(imagePath + "/category" + (index+1) + ".gif");
    }
    
    for (int index = 0; index < numberOfDieFaces; ++index)
    {
      int indexPlus = index+1;
      
      dieImage[index] = loadImage(imagePath + "/red" + indexPlus + ".gif");
      dieSelectedImage[index] = loadImage(imagePath + "/black" + indexPlus + ".gif");
      
      miniDieImage[index] = loadImage(imagePath + "/mini" + indexPlus + ".gif");
    }

    gameCoordinator = new GameCoordinator(numberOfDie);
    
    JPanel diceTrayPanel = new JPanel();
    diceTrayPanel.setLayout(new BoxLayout(diceTrayPanel, BoxLayout.X_AXIS));
    for (int index = 0; index < numberOfDie; ++index)
    {
      dieLabel[index] = new SelectableLabel(index, false);
      dieLabel[index].addMouseListener(
         new java.awt.event.MouseAdapter() {
           public void mouseClicked(java.awt.event.MouseEvent evt) { actionDieMouseClicked(evt); }
         }
      );
      diceTrayPanel.add(dieLabel[index]);
    }
        
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new FlowLayout());
    controlPanel.add(new JLabel("Identity"));
    controlPanel.add(identityText);
    controlPanel.add(connectButton);        
    controlPanel.add(addressText);
    controlPanel.add(new Label("Port:"));
    controlPanel.add(portText);
    controlPanel.add(connectStatusLabel);
    //controlPanel.add(resetButton);
    controlPanel.add(hostButton);
    
    startButton.setEnabled(false);
    controlPanel.add(startButton);
    
    suggestButton.setEnabled(false);
    
    JPanel trayAndCountPanel = new JPanel();
    trayAndCountPanel.setLayout(new FlowLayout());
    trayAndCountPanel.add(diceTrayPanel);
    trayAndCountPanel.add(rollsRemainingLabel);    
    
    JPanel rollControlPanel = new JPanel();
    rollControlPanel.setLayout(new FlowLayout());
    rollControlPanel.add(rollButton);
    rollControlPanel.add(suggestButton);
    
    JPanel scorecardPanel = new JPanel();
    GridBagLayout scorecardLayout = new GridBagLayout();
    scorecardPanel.setLayout(scorecardLayout); //numberOfCategories+4,9,1,1) ); 
    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.BOTH;

    // columns: category, points, roll_p0, score_p0, roll_p1, score_p1, roll_p3, score_p3, roll_p4, score_p4

    identityLabel[0] = new JLabel("Player 1");
    identityLabel[1] = new JLabel("Player 2");
    identityLabel[2] = new JLabel("Player 3");
    identityLabel[3] = new JLabel("Player 4");
    c.weightx = 1.0;
    JLabel categoryHeaderLabel = new JLabel("Category");
    scorecardLayout.setConstraints(categoryHeaderLabel, c);
    scorecardPanel.add( categoryHeaderLabel );     // 1
    scorecardPanel.add( new JLabel(" "));          // 2  points
    scorecardPanel.add( identityLabel[0] );        // 3
    scorecardPanel.add( new JLabel("Score"));      // 4
    scorecardPanel.add( identityLabel[1] );        // 5
    scorecardPanel.add( new JLabel("Score"));      // 6
    scorecardPanel.add( identityLabel[2] );        // 7
    scorecardPanel.add( new JLabel("Score"));      // 8
    scorecardPanel.add( identityLabel[3] );        // 9
    JLabel last_score = new JLabel("Score");
    c.gridwidth = GridBagConstraints.REMAINDER;
    scorecardLayout.setConstraints(last_score, c);
    scorecardPanel.add( last_score );              // 10
        
    for (int categoryIndex = 0; categoryIndex < numberOfCategories; ++categoryIndex)
    {
      if (categoryIndex == 6)
      {
        upperTotalLabel[0] = new JLabel("0");
        upperTotalLabel[1] = new JLabel("0");
        upperTotalLabel[2] = new JLabel("0");
        upperTotalLabel[3] = new JLabel("0");
        
        scorecardPanel.add( new JLabel("Upper Total") );  // 1
        scorecardPanel.add( new JLabel(" ") );            // 2 points
        scorecardPanel.add( new JLabel(" ") );            // 3
        scorecardPanel.add( upperTotalLabel[0] );         // 4
        scorecardPanel.add( new JLabel(" ") );            // 5
        scorecardPanel.add( upperTotalLabel[1] );         // 6
        scorecardPanel.add( new JLabel(" ") );            // 7
        scorecardPanel.add( upperTotalLabel[2] );         // 8
        scorecardPanel.add( new JLabel(" ") );            // 9
        c.gridwidth = GridBagConstraints.REMAINDER;
        scorecardLayout.setConstraints(upperTotalLabel[3], c);
        scorecardPanel.add( upperTotalLabel[3] );         // 10
        
        bonusLabel[0] = new JLabel("0");
        bonusLabel[1] = new JLabel("0");
        bonusLabel[2] = new JLabel("0");
        bonusLabel[3] = new JLabel("0");  
        scorecardPanel.add( new JLabel("Bonus") );        // 1
        scorecardPanel.add( new JLabel(" ") );            // 2 points
        scorecardPanel.add( new JLabel(" ") );            // 3
        scorecardPanel.add( bonusLabel[0] );         // 4
        scorecardPanel.add( new JLabel(" ") );            // 5
        scorecardPanel.add( bonusLabel[1] );         // 6
        scorecardPanel.add( new JLabel(" ") );            // 7
        scorecardPanel.add( bonusLabel[2] );         // 8
        scorecardPanel.add( new JLabel(" ") );            // 9
        c.gridwidth = GridBagConstraints.REMAINDER;
        scorecardLayout.setConstraints(bonusLabel[3], c);
        scorecardPanel.add( bonusLabel[3] );         // 10
      }
      
      categoryLabel[categoryIndex] = new SelectableLabel(categoryIndex, false);
      categoryLabel[categoryIndex].setIcon( categoryImage[categoryIndex] );
      categoryLabel[categoryIndex].addMouseListener(
        new java.awt.event.MouseAdapter() {
          public void mouseClicked(java.awt.event.MouseEvent evt) { actionCategoryMouseClicked(evt); }
          
          public void mouseEntered(java.awt.event.MouseEvent evt) { actionEnteredPointsMotion(evt); }
          public void mouseExited(java.awt.event.MouseEvent evt) { actionExitedPointsMotion(evt); }
        }
      );
      scorecardPanel.add(categoryLabel[categoryIndex]);                     // 1
      
      pointsLabel[categoryIndex] = new SelectableLabel(categoryIndex, false);
      pointsLabel[categoryIndex].setFont(new Font("Courier New",  Font.BOLD, 18));
      pointsLabel[categoryIndex].setText(unknownPoints);
      pointsLabel[categoryIndex].setNumber(categoryIndex);
      scorecardPanel.add(pointsLabel[categoryIndex]);                       // 2
      
      JPanel[] rollPanel = new JPanel[maxPlayersPerGame];
      for (int player = 0; player < maxPlayersPerGame; ++player)
      {
        rollPanel[player] = new JPanel();
        rollPanel[player].setLayout( new BoxLayout(rollPanel[player], BoxLayout.X_AXIS) );
        for (int die = 0; die < numberOfDie; ++die)
        {
          assignedDieLabel[player][die][categoryIndex] = new SelectableLabel(0,  false);
          assignedDieLabel[player][die][categoryIndex].setIcon( blankIcon );
          rollPanel[player].add( assignedDieLabel[player][die][categoryIndex] );

          assignedDieLabel[player][die][categoryIndex].addMouseListener(
            new java.awt.event.MouseAdapter() {
              public void mouseClicked(java.awt.event.MouseEvent evt) { actionAssignedDieClicked(evt); }
            }
          );
        }
        scorecardPanel.add(rollPanel[player]);         // 3, 5, 7, 9
        
        scoreLabel[player][categoryIndex] = new SelectableLabel(0, false);
        scoreLabel[player][categoryIndex].setText("0");
        scoreLabel[player][categoryIndex].setNumber(0);
        if (player == maxPlayersPerGame-1)
        {
          c.gridwidth = GridBagConstraints.REMAINDER;
          scorecardLayout.setConstraints(scoreLabel[player][categoryIndex], c);   
        }
        scorecardPanel.add( scoreLabel[player][categoryIndex] );  // 4, 6, 8, 10
      }
    }
    lowerTotalLabel[0] = new JLabel("0");
    lowerTotalLabel[1] = new JLabel("0");
    lowerTotalLabel[2] = new JLabel("0");
    lowerTotalLabel[3] = new JLabel("0");
        
    scorecardPanel.add( new JLabel("Lower Total") );  // 1
    scorecardPanel.add( new JLabel(" ") );            // 2    
    scorecardPanel.add( new JLabel(" ") );            // 3
    scorecardPanel.add( lowerTotalLabel[0] );         // 4
    scorecardPanel.add( new JLabel(" ") );            // 5
    scorecardPanel.add( lowerTotalLabel[1] );         // 6 
    scorecardPanel.add( new JLabel(" ") );            // 7
    scorecardPanel.add( lowerTotalLabel[2] );         // 8
    scorecardPanel.add( new JLabel(" ") );            // 9
    c.gridwidth = GridBagConstraints.REMAINDER;
    scorecardLayout.setConstraints(lowerTotalLabel[3], c);
    scorecardPanel.add( lowerTotalLabel[3] );         // 10
    
    for (int i = 0; i < grandTotalLabel.length; ++i)
    {
      grandTotalLabel[i] = new SelectableLabel(0, false);
      grandTotalLabel[i].setText("0");
    }
    
    scorecardPanel.add( new JLabel("Grand Total") );  // 1
    scorecardPanel.add( new JLabel(" ") );            // 2
    scorecardPanel.add( new JLabel(" ") );            // 3
    scorecardPanel.add( grandTotalLabel[0] );         // 4
    scorecardPanel.add( new JLabel(" ") );            // 5
    scorecardPanel.add( grandTotalLabel[1] );         // 6
    scorecardPanel.add( new JLabel(" ") );            // 7
    scorecardPanel.add( grandTotalLabel[2] );         // 8
    scorecardPanel.add( new JLabel(" ") );            // 9
    c.gridwidth = GridBagConstraints.REMAINDER;
    scorecardLayout.setConstraints(grandTotalLabel[3], c);
    scorecardPanel.add( grandTotalLabel[3] );         // 10

    Container pane = getContentPane();
    GridBagLayout layout = new GridBagLayout();
    pane.setLayout(layout); 
    c = new GridBagConstraints();
    c.fill = GridBagConstraints.BOTH;
    
    c.weightx = 1.0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    layout.setConstraints(controlPanel, c);
    pane.add(controlPanel);
    
    layout.setConstraints(trayAndCountPanel, c);
    pane.add(trayAndCountPanel);
    
    c.weightx = 0.0;
    layout.setConstraints(rollControlPanel, c);
    pane.add(rollControlPanel);
    
    layout.setConstraints(scorecardPanel, c);
    pane.add(scorecardPanel);
    
    gameStatusLabel.setFont( new Font("Arial Bold", Font.ITALIC, 18) );
    layout.setConstraints(gameStatusLabel, c);
    pane.add(timerLabel);
    pane.add(gameStatusLabel);
    
    connectButton.addActionListener(this);
    rollButton.addActionListener(this);
    suggestButton.addActionListener(this);
    //resetButton.addActionListener(this);
    hostButton.addActionListener(this);
    startButton.addActionListener(this);    
    
    updateRollsRemaining();
    updateDiceTray();
    
    new javax.swing.Timer(1000, updateTimerAction).start();
    
    this.setSize(1020, 720);
  }
  
  ImageIcon loadImage(String filename)
  {
    URL url = this.getClass().getResource(filename);
    if (url != null)
    {
      return new ImageIcon(url);
    }
    setGameStatus("Image file not found - " + filename);
    return null;
  }
  
  private void scrambleAllDie()
  {
    Thread thread = new Thread()
      {
        public void run()
        {
          Random random = new Random();
          long startTime = System.currentTimeMillis();
          long duration = random.nextInt(1200) + 800;
          while (System.currentTimeMillis() - startTime < duration)
          {
            for (int i = 0; i < dieLabel.length; ++i)
            {
              //dieLabel[i].setIcon( dieImage[ random.nextInt(6)] );               
              dieLabel[i].setIcon( dieImage[ random.nextInt(6)] ); 
              dieLabel[i].repaint();
              dieLabel[i].invalidate();
            }
            
            try 
            {
              Thread.sleep( random.nextInt(200) + 50 );
            }
            catch (Exception e)
            {
            }
          }
          updateRollsRemaining();  
          updateDiceTray();
          rollButton.setEnabled(true);
        }
      };  
    thread.start();
  }
  
  private void scrambleSelectedDie()
  {
    Thread thread = new Thread()
      {
        public void run()
        {
          Random random = new Random();
          long startTime = System.currentTimeMillis();
          long duration = random.nextInt(1200) + 800;
          while (System.currentTimeMillis() - startTime < duration)
          {
            for (int i = 0; i < dieLabel.length; ++i)
            {
              if (dieLabel[i].isSelected())
              {
                dieLabel[i].setIcon( dieImage[ random.nextInt(6)] ); 
                dieLabel[i].repaint();
                dieLabel[i].invalidate();
              }
            }
            
            try 
            {
              Thread.sleep( random.nextInt(200) + 50 );
            }
            catch (Exception e)
            {
            }
          }
          updateRollsRemaining();  
          updateDiceTray();
          
          // Check for JOKER
          boolean hasJokerRoll = false;
          if (gameCoordinator.isJokerRoll( gameCoordinator.dieValues()))
          {
            setGameStatus("You have rolled a joker!");
            hasJokerRoll = true;
          }
          
          rollButton.setEnabled(true);
        }
      };  
    thread.start();  
  }  
  
  public void setActivePlayerNumber(int playerNumber)
  {
    assignedPlayerIndex = playerNumber-1;
  }
  public void setCategoryRollForPlayer(int playerIndex, int categoryIndex, Vector roll, int score)
  {
    int true_score = score;
    if (true_score == -1)
    {
      // A category assignment from a client.  Let the servers GameCoordinator calculate the real score.
      true_score = gameCoordinator.score(categoryIndex, roll);
    }
    
    for (int i = 0; i < roll.size(); ++i)
    {
      int roll_i = (Integer)roll.elementAt(i);
      assignedDieLabel[playerIndex][i][categoryIndex].setNumber( roll_i );
      if (roll_i > 0)
      {
        assignedDieLabel[playerIndex][i][categoryIndex].setIcon( miniDieImage[ roll_i - 1 ] );
      }
      else
      {
        assignedDieLabel[playerIndex][i][categoryIndex].setIcon( blankIcon );
      }
    }
    scoreLabel[playerIndex][categoryIndex].setText(Integer.toString(true_score));
    scoreLabel[playerIndex][categoryIndex].setNumber(true_score);
    
    if (score == -1)
    {
      yahtzeeServer.broadcastCategoryAssignments(assignedDieLabel, scoreLabel);      
    }
    updateUpperLowerTotals();
  }

  public void setConnectStatus(String status)
  {
    connectStatusLabel.setText(status);
  }
  
  public void setGameStatus(String status)
  {
    gameStatusLabel.setText(status);
  }

  public void setPlayerName(int playerNumber, String playerName)
  {
    int playerIndex = playerNumber-1;
    identityLabel[playerIndex].setText(playerName);
    this.playerName[playerIndex] = playerName;
  }
  
  public void setPlayerName(String newIdentityName)
  {
    identityLabel[assignedPlayerIndex].setText(newIdentityName);
    playerName[assignedPlayerIndex] = newIdentityName;
  }  
  
  public void setPlayerToGo(int playerNumberToGo)
  {
     if (playerNumberToGo-1 == this.assignedPlayerIndex)
     {
       yourTurn();
     }
     else
     {
       setGameStatus( identityLabel[playerNumberToGo].getText() + "'s turn.");
     }
  }  
  
  private void updateDiceTray()
  {
    Vector dieValues = gameCoordinator.dieValues(); 
    for (int index = 0; index < numberOfDie; ++index)
    {
      int dieFaceValue = (Integer)dieValues.elementAt(index);
      if (dieFaceValue == Die.face_unknown)
      {
        dieLabel[index].setIcon( yahtzeeIcon );
      }
      else
      {
        dieLabel[index].setIcon( dieImage[ dieFaceValue - 1 ] );
      }
      dieLabel[index].unselect();
    }    
  }
  
  private void updateRollsRemaining()
  {
    switch ( gameCoordinator.rollsRemaining() )
    {
      case 3:
        rollsRemainingLabel.setIcon( threeIcon );
        break;
      case 2:
        rollsRemainingLabel.setIcon( twoIcon );
        break;
      case 1:
        rollsRemainingLabel.setIcon( oneIcon );
        break;
      default:
        rollsRemainingLabel.setIcon( zeroIcon );
        break;
    }
  }
  
  private void updateUpperLowerTotals()
  {
    int[] lowerSum = new int[maxPlayersPerGame];
    int[] upperSum = new int[maxPlayersPerGame];

    for (int i = 0; i < maxPlayersPerGame; ++i)
    {
      lowerSum[i] = 0;
      upperSum[i] = 0;
      
      int upperBonus = 0;
      for (int j = 0; j < numberOfCategories; ++j)
      {
        if (j < 6)
        {
          upperSum[i] += scoreLabel[i][j].getNumber();  
          if (upperSum[i] >= 63)
          {
            upperBonus = 35;
          }
        }
        else
        {
          lowerSum[i] += scoreLabel[i][j].getNumber();
        }
      }
      upperTotalLabel[i].setText( Integer.toString( upperSum[i] ) );      
      bonusLabel[i].setText( Integer.toString(upperBonus) );
      lowerTotalLabel[i].setText( Integer.toString( lowerSum[i] ) );
      grandTotalLabel[i].setText( Integer.toString( upperSum[i] + lowerSum[i] + upperBonus ) );
      grandTotalLabel[i].setNumber( upperSum[i] + lowerSum[i] + upperBonus );
    }
  }  

  public void yourTurn()
  {
    updateRollsRemaining();    
    rollButton.setEnabled(true);
    if ( (yahtzeeServer != null) || (yahtzeeClient != null) )
    {
      // Single player mode.
      setConnectStatus("It is your turn!");
    }
    
    // Determine End of Game status
    if (yahtzeeServer != null)
    {
      if ( (yahtzeeServer.getGameTurns()+1) >= (numberOfCategories*(yahtzeeServer.getNumConnectedClients()+1)) )
      {
        winnerIndex = 0;  // first assume player 1 has won the game... (then check the other player scores)
        for (int i = 1; i < scoreLabel.length; ++i)
        {
          if ( grandTotalLabel[i].getNumber() > grandTotalLabel[winnerIndex].getNumber() )
          {
            winnerIndex = i;
          }
        }
        // Broadcast to all the clients who win the game
        yahtzeeServer.broadcastWinner(winnerIndex+1);
        // And report to self who won the game...
        gameOver(winnerIndex+1);        
      }
    }
    else if (yahtzeeClient != null)
    {
      // Single Player Mode
      if (gameCoordinator.turnCount()+1 >= numberOfCategories)
      {
        winnerIndex = 0;
        gameOver(winnerIndex+1);
      }
    }    
  }        

  private static void createAndShowGUI()  // part of main(String[])
  {
   JFrame.setDefaultLookAndFeelDecorated(true);
      
    JApplet applet = new YahtzeeApplet();
    applet.init();
    //applet.start(); 
      
    JFrame frame = new JFrame("Yahtzee");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().setLayout(new GridBagLayout());
    frame.getContentPane().add(applet);
    frame.pack();
      
    frame.setVisible(true);
  }
  
  public static void main(String[] args)
  {
    // If running as an applet...
    
    javax.swing.SwingUtilities.invokeLater(
      new Runnable() 
      {
        public void run() 
        {
          createAndShowGUI();
        }
      }
    );
     
/*
    // If running as an application... NOTE: YahtzeeApplet needs to derive from JFrame if you do this
    
    YahtzeeApplet yahtzee = new YahtzeeApplet();
    yahtzee.init();
    yahtzee.setVisible(true);
    yahtzee.addWindowListener(
       new WindowAdapter()
       {
         public void windowClosing(WindowEvent e)
         {
           System.exit(0);
         }
       }
    );
*/    
  }

}
